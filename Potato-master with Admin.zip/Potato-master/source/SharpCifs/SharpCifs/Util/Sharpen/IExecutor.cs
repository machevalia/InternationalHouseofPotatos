namespace SharpCifs.Util.Sharpen
{
    public interface IExecutor
	{
		void Execute (IRunnable runnable);
	}
}
