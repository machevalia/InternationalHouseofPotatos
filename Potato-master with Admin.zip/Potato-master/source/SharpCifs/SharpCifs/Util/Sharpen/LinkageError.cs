using System;

namespace SharpCifs.Util.Sharpen
{
    internal class LinkageError : Exception
	{
		public LinkageError (string msg) : base(msg)
		{
		}
	}
}
